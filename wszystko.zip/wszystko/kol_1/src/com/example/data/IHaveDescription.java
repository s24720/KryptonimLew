package com.example.data;

public interface IHaveDescription {
    String getDescription();
}
