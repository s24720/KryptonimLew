package example.interfacexe;

public class Main {
    public static void main(String[] args) {
        Main main = new Main();

        double argument1 = 4;
        double argument2 = 5;

        Addition addition = new Addition();
        Multiplication multiplication = new Multiplication();

        addition.compute(argument1, argument2);
        multiplication.compute(argument1, argument2);

        System.out.println("Wynik: " + addition);
        System.out.println("Wynik: " + multiplication);

    }



}
