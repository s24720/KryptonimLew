package example.interfacexe;

public interface Computation {
    double compute(double argument1, double argument2);
}
