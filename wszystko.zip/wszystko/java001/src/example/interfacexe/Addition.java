package example.interfacexe;

public class Addition implements Computation {

    private double add;

    public double getAdd() {
        return add;
    }

    public void setAdd(double add) {
        this.add = add;
    }

    @Override
    public double compute(double argument1, double argument2) {
        this.add = argument1 + argument2;
        return this.add;
    }

    @Override
    public String toString() {
        return "Addition{" +
                "add=" + add +
                '}';
    }
}
