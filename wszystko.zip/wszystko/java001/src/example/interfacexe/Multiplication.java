package example.interfacexe;

public class Multiplication implements Computation{

    private double mult;

    public double getMult() {
        return mult;
    }

    public void setMult(double mult) {
        this.mult = mult;
    }

    @Override
    public double compute(double argument1, double argument2) {
         this.mult = argument1 * argument2;
         return this.mult;
    }

    @Override
    public String toString() {
        return "Multiplication{" +
                "mult=" + mult +
                '}';
    }
}
