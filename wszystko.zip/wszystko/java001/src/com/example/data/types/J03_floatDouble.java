package com.example.data.types;

public class J03_floatDouble {
    public static void main(String[] args) {
        float number = 10.5f; //Do typu float dodwać na końcu f
        double bigNumber = 23.32423423d; //Do typu double warto dodwać na końcu d

        System.out.println("Number: " + number + " bigNumber: " + bigNumber);
    }
}
