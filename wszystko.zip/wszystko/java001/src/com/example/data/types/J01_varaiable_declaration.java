package com.example.data.types;

public class J01_varaiable_declaration {

    public static void main(String[] args) {
        int number = 24;
        System.out.println("wartość: " + number);

        int data = -123;
        System.out.println("data: " + data);

        number =  data * 2;

        System.out.println("number: " + number);


    }

}
