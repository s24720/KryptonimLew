package com.example.data.types;

public class J02_byte_short_int_long {

    public static void main(String[] args) {

        //Typy proste - prymitywy

        byte small = -127;
        short numShort = 32000;
        int number = 12345;
        long big = 1231243424L; //Do typu long dodwać na końcu duże L
    }
}
