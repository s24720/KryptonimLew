package com.example.data.types;

public class J05_variableNames {
    public static void main(String[] args) {
        //Nazwa powinna odzwierdziedlać to co przechowuje

        int _age = 21;
        int currentHour = 12;
        float moneyInThePocket = 12.12f;
        double $speed = 100.10d;

    }

}
