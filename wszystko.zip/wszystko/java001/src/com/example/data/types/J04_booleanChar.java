package com.example.data.types;

public class J04_booleanChar {
    public static void main(String[] args) {

        boolean flag1 = true;
        boolean flag2 = false;

        System.out.println("flag1: " + flag1 + " flag2: " + flag2);

        char sign1 = '\u004A';

        System.out.println("char sign: " + sign1);
    }
}
