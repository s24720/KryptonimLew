package com.example.data.types;

public class J08_finalKewword {
    public static void main(String[] args) {
        int number = 10;
        number = 32;

        final int num2 = 100;
    }
}
