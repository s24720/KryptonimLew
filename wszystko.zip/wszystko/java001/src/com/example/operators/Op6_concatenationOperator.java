package com.example.operators;

public class Op6_concatenationOperator {
    public static void main(String args[]) {

        String s1 =" Hello ";
        String s2 = s1 + "World!"; // + to operator konkatenacji
        System.out.println(s2);
    }
}
