package com.example.oop.basic.inheritance.example2_shop;

public class Mouse extends Products{
    public int numButtons;

    Mouse(){
        numButtons = 3;
    }

}
