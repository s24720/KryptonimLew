package com.example.oop.basic.packages;

public class SomeClass {
}
