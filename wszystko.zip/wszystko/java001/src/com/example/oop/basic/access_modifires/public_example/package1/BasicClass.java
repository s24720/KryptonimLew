package com.example.oop.basic.access_modifires.public_example.package1;

public class BasicClass {
    public String name;


    public String getName() {
        return name;
    }

    public void setName(String name){
        this.name = name;
    }
}
