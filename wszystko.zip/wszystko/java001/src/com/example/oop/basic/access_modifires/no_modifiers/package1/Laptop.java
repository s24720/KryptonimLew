package com.example.oop.basic.access_modifires.no_modifiers.package1;

public class Laptop extends Product {
    public Laptop(){
        name = "Laptop";
    }
}
