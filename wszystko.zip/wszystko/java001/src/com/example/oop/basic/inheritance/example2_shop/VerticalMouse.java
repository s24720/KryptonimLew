package com.example.oop.basic.inheritance.example2_shop;


public class VerticalMouse  extends Mouse {

    VerticalMouse(){

    }
}
