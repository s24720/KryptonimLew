package com.example.oop.basic.interface_basics;

public interface Flying {
    public void increaseHeight();
    public void decreaseHeight();
}
