package com.example.oop.basic.interface_extends_default_static_final_methods;

public interface Animal {
    public int getNumLegs();
    public String getName();

}
