package com.example.oop.basic.packages;

import com.example.oop.basic.methods.InvokingMethods;
import com.example.oop.basic.methods.*;

import java.util.Date;

public class PackagesTest {
    public static void main(String[] args) {
        SomeClass someClass = new SomeClass();
        InvokingMethods invokingMethods = new InvokingMethods();
        Date date = new Date();
    }
}
