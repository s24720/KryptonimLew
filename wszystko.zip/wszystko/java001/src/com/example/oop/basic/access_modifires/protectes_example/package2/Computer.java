package com.example.oop.basic.access_modifires.protectes_example.package2;

import com.example.oop.basic.access_modifires.protectes_example.package1.Product;

public class Computer extends Product {
    public Computer() {
        name = "Computer";
    }
}
