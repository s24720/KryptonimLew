package com.example.oop.basic.inheritance.example2_shop;

public class Monitor extends Products{
    public int resulution;

    Monitor(){
        resulution = 1080;
    }
}
