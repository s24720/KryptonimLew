package com.example.oop.basic.access_modifires.private_example;

public class Car extends  Product{

    public Car(){
        super("unknownCar");

    }
}
