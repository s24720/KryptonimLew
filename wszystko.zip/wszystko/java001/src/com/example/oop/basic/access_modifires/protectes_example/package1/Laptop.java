package com.example.oop.basic.access_modifires.protectes_example.package1;

public class Laptop extends Product{
    public Laptop(){
        name = "Laptop";
    }
}
