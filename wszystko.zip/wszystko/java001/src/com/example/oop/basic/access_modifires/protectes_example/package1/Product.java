package com.example.oop.basic.access_modifires.protectes_example.package1;

public class Product {
    protected String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
