package com.example.oop.basic.access_modifires.public_example.package2;

import com.example.oop.basic.access_modifires.public_example.package1.BasicClass;

public class OtherClass extends BasicClass {

    public OtherClass(){
        name = "OtherClass";
        this.setName("otherClass");

    }




}
