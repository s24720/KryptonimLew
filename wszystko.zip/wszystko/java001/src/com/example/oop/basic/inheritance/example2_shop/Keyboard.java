package com.example.oop.basic.inheritance.example2_shop;

public class Keyboard extends Products{
    public int numKeys;

    Keyboard(){
        numKeys = 104;
        price = 300.0f;
    }
}
