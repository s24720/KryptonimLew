package org.example.model;

import org.example.Info;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ClassDescriptor {
    private Class<?> clazz;

    public ClassDescriptor(Class<?> c){
        this.clazz = c;
    }

    public String getFullName(){
        return this.clazz.getClass().getName();
    }

    public List<String> getMethodNames(){
        return Arrays.stream(this.clazz.getClass().getDeclaredMethods()).map(m-> m.getName()).toList();
    }

    public List<String> getFieldNames(){
        return Arrays.stream(this.clazz.getClass().getDeclaredFields()).map(m-> m.getName()).toList();
    }

    //for (Field f: MyClass.class.getFields()) {
    //   Column column = f.getAnnotation(Column.class);
    //   if (column != null)
    //       System.out.println(column.columnName());
    //}
    public String getInfo(){
        String returnString = "";
        for (Field f  : this.clazz.getDeclaredFields()) {
            Info i = f.getAnnotation(Info.class);
            if (i != null){
                returnString = i.nr() + " " + i.firstName() + " " + i.firstName();
            } else {
                returnString = null;
            }
        }
        return returnString;
    }

}
