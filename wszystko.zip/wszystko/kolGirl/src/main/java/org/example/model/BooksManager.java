package org.example.model;

import org.example.IManageBooks;
import org.example.data.Book;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class BooksManager implements IManageBooks {

    @Override
    public List<Book> getByTitle(List<Book> books, String keyword) {
        return books.stream()
                        .filter(book -> book.getTitle().equalsIgnoreCase(keyword)).toList();
    }

    @Override
    public List<String> getDescription(List<Book> books) {
        return books.stream()
                .map(Book::getDescription).toList();
    }

    @Override
    public Map<Integer, List<Book>> groupByPublicationYear(List<Book> books) {
        return books.stream()
                .collect(Collectors.groupingBy(book -> (Integer) book.getPublicationDate().getYear())).toMap();
    }

    @Override
    public double getTotalPrice(List<Book> books) {
        return books.stream().collect(Collectors.summarizingDouble(books.getPrice())).getSum();
    }
}
