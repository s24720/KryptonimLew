package org.example.model;

import org.example.IHaveData;

import org.example.data.Book;
import java.util.ArrayList;
import java.util.List;

public class Library<Book> implements IHaveData<Book> {
    private List<Book> data = new ArrayList<>();

    public Library(List<Book> b){
        this.data = b;
    }

    @Override
    public List getData() {
        return this.data;
    }

    @Override
    public void showData() {
        for (Book book : data) {
            System.out.println(book.getDescription());
        }
    }


}
