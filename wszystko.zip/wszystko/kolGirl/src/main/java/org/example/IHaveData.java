package org.example;

import java.util.List;

public interface IHaveData <TItem> {
    List<TItem> getData();
    void showData();
}
