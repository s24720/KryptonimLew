package org.example;

import org.example.data.Book;
import org.example.model.ClassDescriptor;
import org.example.model.Library;
import org.example.data.BooksSample;

import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        // JA WIEM ZE TO NIE DZIALA ALE POWINNO TYLKO SIE JAKAS INNA KSIAZKA POBIERA I TO NIE DZIALA
        // ALE LOGIKA JEST RACZEJ W WIEKSZOSCI W PORZADKU :C

        System.out.println("Zaczynamy. Życzę powodzenia :)");

        Library library = new Library(BooksSample.books);

        ClassDescriptor bookDescriptor = new ClassDescriptor(Book.class);
        System.out.println(bookDescriptor.getInfo());
    }

    private static double getPriceOfJavaBooksPublicizedIn2002(List<Book> books){
        return books
                .stream()
                .filter(book -> book.getTitle().equalsIgnoreCase("java"))
                .filter(book -> book.getPublicationDate().getYear() == 2002)
                .collect(Collectors.summarizingDouble(books.getPrice()))
                .getSum();
    }

    private static void showNetBooksPublicizedIn2001(){
        String print = BooksSample.books
                .stream()
                .filter(book -> book.getTitle().equalsIgnoreCase("net"))
                .filter(book -> book.getPublicationDate().getYear() == 2001)
                .map(Book::getDescription)
                .toString();
        System.out.println(print);
    }
}