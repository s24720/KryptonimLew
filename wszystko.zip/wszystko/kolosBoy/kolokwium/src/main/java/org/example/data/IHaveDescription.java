package org.example.data;

public interface IHaveDescription {
    String getDescription();
}
