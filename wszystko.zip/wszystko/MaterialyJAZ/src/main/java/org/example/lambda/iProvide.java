package org.example.lambda;
@FunctionalInterface
public interface iProvide {
   void print();
}
