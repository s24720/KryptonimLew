package org.example.model;

public enum Gender {
    MALE, OTHER, FEMALE
}
