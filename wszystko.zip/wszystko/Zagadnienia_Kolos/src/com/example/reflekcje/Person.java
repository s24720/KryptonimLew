package com.example.reflekcje;

import java.time.LocalDate;

public abstract class Person implements IHaveld{

    private long id;
    private String firstname;
    private String lastname;
    private LocalDate dateOfBirth;

    public Person() {
    }
// konsruktor
    public Person(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    // getery i setery
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    // prywatna metoda String zwracająca dane
    private String details(){
        return "Siema! Jestem " + firstname + " " + lastname;
    }
    // Metoda void drukująca dane o osobie
    public void printDetails(){
        System.out.println(details());
    }

    // Metoda void drukująca dane o pracowniku
    public static void print(Employee employee){
        employee.printDetails();
    }
}
