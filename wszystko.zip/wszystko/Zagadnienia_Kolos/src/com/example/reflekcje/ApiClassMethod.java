package com.example.reflekcje;

public class ApiClassMethod {
}
