package com.example.reflekcje;

// Interace z pramterem getId()
public interface IHaveld {
    long getId();
}
