package com.example.reflekcje;

public class Employee extends Person{


    double income; //dochód

    public Employee() {
        this(0);
    }

    // konstruktor z paratemter income
    public Employee(double income) {
        this("","", 0);
        this.income = income;
    }

    // konstrukot z parametrami klasy Person i Employee
    public Employee(String firstname, String lastname, double income) {
        super(firstname, lastname);
        this.income = income;
    }

    // getter i setter
    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    // Prywatna metoda wyświetlająca wiadomość
    private void secretAction(){
        System.out.println("I do something in secret...");
    }
}
