package com.example.reflekcje;

import com.example.reflekcje.Employee;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, // zgłasza gdy nie można znaleźć określonej klasy // https://www.tabnine.com/code/java/classes/java.lang.NoSuchMethodException
            InvocationTargetException, // sprawdzony wyjątek, który otacza wyjątek zgłoszony przez wywołaną metodę lub konstruktora. // https://docs.oracle.com/javase/7/docs/api/java/lang/reflect/InvocationTargetException.html
            IllegalAccessException // jest generowany, gdy aplikacja próbuje refleksyjnie utworzyć instancję (inną niż tablica), ustawić lub pobrać pole lub
    // wywołać metodę, ale aktualnie wykonywana metoda nie ma dostępu do definicji określonej klasy, pola, metoda lub konstruktor. // https://docs.oracle.com/javase/7/docs/api/java/lang/IllegalAccessException.html

    {


        var employee = new Employee(); // wywołanie klasy employee
//        funWithTypes(employee.getClass());
//        funWithConstructors(employee.getClass());
        funWithMethods(employee.getClass());  // Metoda Object.getClass()służy do pobierania klasy wykonawczej obiektu.
    }


// Instancje klasy Class reprezentują klasy i interfejsy w uruchomionej aplikacji Java

    private static void funWithTypes(Class<?> clazz) {

        String className = clazz
                //.getSimpleName() // Zwraca prostą nazwę klasy bazowej, jak podano w kodzie źródłowym.
                //.getName() // Zwraca nazwę metody reprezentowanej przez ten Method obiekt jako String wraz ze ścieżką
                .getPackageName() // zwraca nazwe pakietu
                ;

        System.out.println(className); // drukuje wyowałną metodę

        String superClassName = clazz.getSuperclass() // getSuperclass() Zwraca klasę reprezentującą bezpośrednią klasę nadrzędną jednostki (klasy, interfejsu, typu pierwotnego lub pustego) reprezentowaną przez tę klasę.
                //.getSimpleName() // // Zwraca prostą nazwę klasy nadrzędnej, jak podano w kodzie źródłowym.
                //.getName() // Zwraca nazwę metody nadrzjędenej reprezentowanej przez ten Method obiekt jako String wraz ze ścieżką
               .getPackageName() // zwraca nazwe pakietu
                ;

        System.out.println(superClassName);

        var interfaces = Arrays.stream(clazz.getInterfaces()).toList(); // getInterfaces Zwraca interfejsy bezpośrednio zaimplementowane przez klasę lub interfejs reprezentowany przez ten obiekt klasy.

        interfaces.forEach(x->
                System.out.println(x.getName()) // zwraca nazwę zaimplementowanego interfejsu
        );

        var superClassInterfaces = Arrays.stream(clazz.getSuperclass().getInterfaces()).toList(); // gerSuperclass Zwraca klasę reprezentującą bezpośrednią klasę nadrzędną jednostki (klasy, interfejsu, typu pierwotnego lub pustego) reprezentowaną przez tę klasę.

        superClassInterfaces.forEach(x->
                System.out.println(x.getName()) // zwraca nazwę zaimplementowanego interfejsu która jest zaimplentowana przez nadrzędną klasę
        );
    }







    private static void funWithConstructors(Class<?> clazz) {

        var constructors = Arrays.stream(clazz.getConstructors()).toList(); // getConstructors zwraca tablicę zawierającą obiekty Constructor odzwierciedlające wszystkie publiczne konstruktory klasy reprezentowanej przez ten obiekt Class.
        message("konstruktory klasy Employee");
        constructors.forEach(constructor->{
            var name = constructor.getName(); // Zwraca nazwę tego konstruktora wraz z ścieżką jako ciąg znaków.
            var arguments = constructor.getParameters(); // Zwraca tablicę obiektów Parameter, które reprezentują wszystkie parametry do podstawowego pliku wykonywalnego reprezentowanego przez ten obiekt. Zwraca tablicę o długości 0, jeśli plik wykonywalny nie ma parametrów.
            var modifiers = constructor.getModifiers(); // Zwraca modyfikatory języka Java dla pliku wykonywalnego reprezentowanego przez ten obiekt.
            System.out.println(Modifier.toString(modifiers) // zwraca modyfikator
                    + " " + name +" has "
                    +constructor.getParameterCount() +" parameters"); // zwraca ilość parametrów
        });


        var employees = constructors.stream()
                .map(constructor-> {
                    try {
                        if(constructor.getParameterCount()==1)
                            return constructor.newInstance(100);
                    } catch (Exception e) {
                    }
                    return null;
                }).filter(x->x!=null).toList();
        System.out.println(employees.get(0)); // zwraca pracownika o tym indeksie
    }






    private static void funWithMethods(Class<?> clazz) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        message("Wszystkie metody klasy Employee (także metody klas nadrzędnych)");
        var methodList = Arrays.stream(clazz.getMethods()).toList(); // getMethod Zwraca tablicę zawierającą obiekty Method odzwierciedlające wszystkie publiczne metody klasy lub interfejsu reprezentowane przez ten obiekt Class, w tym te zadeklarowane przez klasę lub interfejs oraz te odziedziczone z nadklas i superinterfejsów.

        methodList.forEach(
                method->{
                    var name = method.getName(); // zwraca nazwę metody
                    var modifier = method.getModifiers(); // zwraca nazwę modyfikatora
                    var modifierInString = Modifier.toString(modifier);
                    var parameters = method.getParameterTypes(); // zwraca typ parametru
                    System.out.println(modifierInString +" " + name + " has " + method.getParameterCount()+ " parameters");
                }
        );



        var tmp = new Employee();
        message("Metody z klasy Employee");
        var declaredMethods = Arrays.stream(clazz.getDeclaredMethods()); // getDeclaredMethods Zwraca tablicę zawierającą obiekty Method odzwierciedlające wszystkie zadeklarowane metody klasy lub interfejsu reprezentowane przez ten obiekt Class, w tym metody publiczne, chronione, domyślne (pakietowe) i prywatne, ale z wyłączeniem metod dziedziczonych
        declaredMethods.forEach(
                method->{
                    var name = method.getName();
                    var modifier = method.getModifiers();
                    var modifierInString = Modifier.toString(modifier);
                    var parameters = method.getParameterTypes();
                    System.out.println(modifierInString +" " + name + " has " + method.getParameterCount()+ " parameters");
                }
        );



        message("Test działania/wywoływania metod");
        var employee = new Employee("jan", "nowak", 5000);

        var printMethod = clazz.getMethod("printDetails");
        printMethod.invoke(employee);
        var setIdMethod = clazz.getDeclaredMethod("setIncome", double.class);
        setIdMethod.invoke(employee, 1200);
        var getIdMethod = clazz.getDeclaredMethod("getIncome");
        System.out.println("nowa pensja: " + getIdMethod.invoke(employee));

        message("wywoływanie metody prywatnej");
        //employee.secretAction(); // nie można tak !!

        var secretMethod = clazz.getDeclaredMethod("secretAction");
        secretMethod.setAccessible(true);
        secretMethod.invoke(employee);
    }

    public static void message(String message){
        System.out.println("\n****************************************************");
        System.out.println("\t\t"+message);
        System.out.println("****************************************************\n");
    }
}