package com.example.Material.model;

public enum Gender {
    MALE, OTHER, FEMALE
}
