package com.example.Material.lambda;


import com.example.Material.model.Gender;

import java.util.ArrayList;
import java.util.List;

public class SearchParameters {
   private List<Gender> genders = new ArrayList<>();

   public List<Gender> getSelectedGenders(){
        return genders;
    }
}
