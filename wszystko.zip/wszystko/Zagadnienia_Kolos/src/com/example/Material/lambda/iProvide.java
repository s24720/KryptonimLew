package com.example.Material.lambda;
@FunctionalInterface
public interface iProvide {
   void print();
}
