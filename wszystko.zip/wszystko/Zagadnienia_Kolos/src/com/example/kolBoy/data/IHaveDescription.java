package com.example.kolBoy.data;

public interface IHaveDescription {
    String getDescription();
}
