package com.example.kolBoy.data;

import java.util.List;

public interface IHaveData<TItem extends IHaveDescription> {
    List<TItem> getData();

    void showData();
}
