package com.example.lambda.observables;

import com.example.lambda.abstrakcion.IAmWaitingForAnOrder;

// Klasa Waiter implementuje Interface IAmWaitingForAnOrder
public class Waiter implements IAmWaitingForAnOrder {

    @Override // Wywoałenie metody z inteface ShouldStartWork
    public boolean ShouldStartWork(Order meal) {
        return false;
    }
}
