package com.example.lambda.observables;

import com.example.lambda.abstrakcion.Worker;

// Klasa ChipsWorker roszerza klasę Worker, która przyjmuje jako parametr klasę Chips
// Możliwe jest to dlatego, że klasa Chips rozszerzona jest przez klasę Meal
public class ChipsWorker extends Worker<Chips> {


    @Override // Wyowałenie metody prepare z klasy Worker, która przyjmuje za parametr genryczny klasę Chips, oraz jako argument Klasę Order
    public Chips prepare(Order order) {

        return new Chips();
    }

    @Override // Metoda boolean przyjmuje za argument klasę Order
    public boolean ShouldStartWork(Order order) {
        return order.isChipsIncluded();
    }


}
