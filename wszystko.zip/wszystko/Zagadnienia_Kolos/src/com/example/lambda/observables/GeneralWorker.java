package com.example.lambda.observables;

import com.example.lambda.abstrakcion.IAmWaitingForAnOrder;
import com.example.lambda.abstrakcion.IPrepareMeal;
import com.example.lambda.abstrakcion.Meal;
import com.example.lambda.abstrakcion.Worker;


// Klasa zawiera papametr generyczny rozszerzany przez Meal
// Cąła klasa roszerzona jest przez klasę Worker, która zawiera parametr generyczny TMeal
public class GeneralWorker<TMeal extends Meal> extends Worker<TMeal> {

    IAmWaitingForAnOrder waiter;
    IPrepareMeal<TMeal> prepareMeal;


    // konstruktor
    public GeneralWorker(IAmWaitingForAnOrder waiter, IPrepareMeal<TMeal> prepareMeal) {
        this.waiter = waiter;
        this.prepareMeal = prepareMeal;
    }

    @Override
    public TMeal prepare(Order order) { // Wyowałenie metody prepare z klasy Worker, która nie przyjmuje nic parametr genryczny, oraz jako argument przyjmuje Klasę Order
        return this.prepareMeal.prepare(order);
    }

    @Override  // Wyowałenie metody ShouldStartWork z klasy Worker, która przyjmuje jako argument przyjmuje Klasę Order
    public boolean ShouldStartWork(Order meal) {
        return this.waiter.ShouldStartWork(meal);
    }
}
