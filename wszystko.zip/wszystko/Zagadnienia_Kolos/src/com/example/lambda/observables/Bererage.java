package com.example.lambda.observables;

import com.example.lambda.abstrakcion.Meal;

// klasa rozszerzająca klasę Meal
public class Bererage extends Meal {
}
