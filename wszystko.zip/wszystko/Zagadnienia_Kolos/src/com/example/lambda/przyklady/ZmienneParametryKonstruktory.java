package com.example.lambda.przyklady;

public class ZmienneParametryKonstruktory {


}
