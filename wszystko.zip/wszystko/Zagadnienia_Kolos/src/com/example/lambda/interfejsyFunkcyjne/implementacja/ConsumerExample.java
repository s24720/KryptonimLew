package com.example.lambda.interfejsyFunkcyjne.implementacja;

import com.example.lambda.interfejsyFunkcyjne.Consumer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ConsumerExample {
    public static final List<String> CUSTOMERS = Arrays.asList("Ania", "Piotrek", "Mateusz", "Kasia", "Tomek");

    public static void main(String[] args) {

//
//        List<String> names = new ArrayList<>();
//        names.add("Ania");
//        names.add("Tomek");
//        names.add("Janusz");
//        Consumer<String> action = name -> System.out.println("Name is " + name);
//        names.forEach(action);
//

        System.out.println("Interfjesy funkcyjne: ");
        System.out.println("https://programuj.pl/blog/java8-lambdy-praktyczne-przyklady");
        System.out.println("https://developeronthego.pl/java-8-interfejsy-funkcyjne-przeglad/");

        //Konsument (Consumer) to najprostszy z interfejsów funkcyjnych. Służy on do zapisania operacji,
        // jaka ma być wykonana na danym elemencie. Definiuje się je poprzez zdefiniowanie implementacji z metodą accept (np. lambdą).

        System.out.println("\n----------------------------Consumer--------------------------------\n");



        System.out.println("--- WYPISANIE KLIENTÓW ---");
        // dla każdego klienta 'c' wykonaj `System.out.println(c);'
        performOnAllCustomers(c -> System.out.println(c));

        System.out.println("--- WYPISANIE KLIENTÓW DUŻYMI LITERAMI ---");
        // dla każdego klienta 'c' wykonaj `System.out.println(c.toUpperCase());'
        performOnAllCustomers(c -> System.out.println(c.toUpperCase()));

        System.out.println("--- WYPISANIE DŁUGOŚCI IMION KLIENTÓW ---");
        performOnAllCustomers(c -> System.out.println(c + ": " + c.length()));

    }

    public static void performOnAllCustomers(Consumer<String> consumer) {
        for (String customer : CUSTOMERS) {
            consumer.accept(customer);
        }
    }

}
