package com.example.lambda.interfejsyFunkcyjne.implementacja;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ComparatorExample {
    public static void main(String[] args) {

        System.out.println("Interfjesy funkcyjne: ");
        System.out.println("https://programuj.pl/blog/java8-lambdy-praktyczne-przyklady");
        System.out.println("https://developeronthego.pl/java-8-interfejsy-funkcyjne-przeglad/");


        int[] array = {5,4,8,3};

        System.out.println("Tablica PRZED posortowaniem: " + Arrays.toString(array));
        // sortowanie tablicy
        Arrays.sort(array);
        System.out.println("Tablica PO posortowaniu: " + Arrays.toString(array));

        List<Integer> collection = new ArrayList<>(Arrays.asList(8, 4, 9, 5));

        System.out.println("Kolekcja PRZED posortowaniem: " + collection);
        Collections.sort(collection);
        System.out.println("Kolekcja PO posortowaniu: " + collection);
    }
}
