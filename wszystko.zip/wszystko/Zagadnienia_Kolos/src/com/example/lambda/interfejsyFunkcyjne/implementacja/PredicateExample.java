package com.example.lambda.interfejsyFunkcyjne.implementacja;

import com.example.lambda.interfejsyFunkcyjne.Predicate;

class PredicateTest {
    public static void main(String[] args) {
        System.out.println("Interfjesy funkcyjne: ");
        System.out.println("https://programuj.pl/blog/java8-lambdy-praktyczne-przyklady");
        System.out.println("https://developeronthego.pl/java-8-interfejsy-funkcyjne-przeglad/");

//        Kolejnym bardzo ważnym interfejsem (bardzo często używany w strumieniach) jest Predicate czyli
//          predykat - umożliwia zapisanie zachowania "czy dany element spełnia warunek". Z jego pomocą definiujemy metodę test, która przyjmuje element i
//        zwraca wartość typu boolean - czy element spełnia warunek.


        System.out.println("\n----------------------------Predicate--------------------------------\n");


        // predykat sprawdzający, czy dany String jest dłuższy niż 4 znaki
        Predicate<String> is4CharsLongPredicate = x -> x.length() > 4;

        boolean result1 = is4CharsLongPredicate.test("Ala");
        System.out.println("Test predykatu dla napisu \"Ala\": " + result1);

        boolean result2 = is4CharsLongPredicate.test("Adrianna");
        System.out.println("Test predykatu dla napisu \"Adrianna\": " + result2);
    }
}