package com.example.lambda.interfejsyFunkcyjne;

//Zadaniem tego typu interfejsów jest produkowanie (dostarczanie) danych. Możesz go rozumieć jako metodę, która nie przyjmuje żadnego parametru ale zawraca jakieś wartości.
@FunctionalInterface
public interface Supplier<T> {

    /**
     * Gets a result.
     *
     * @return a result
     */

    T get();
}
