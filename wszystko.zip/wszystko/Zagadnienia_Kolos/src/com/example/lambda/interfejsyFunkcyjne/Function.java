package com.example.lambda.interfejsyFunkcyjne;

//Interfejsy funkcyjne typu Function są jednymi z najczęściej używanych. Powodem jest to, że łączy on strukturę zarówno intefejsów Supplier,
//        jak i Concumer. Jest on odpowiedzią na potrzebę stworzenia funkcji, która będzie zarówno przyjmować jakiś parametr,
//        jak i go przetwarzać i zwracać rezultat, będący innym obiektem
@FunctionalInterface
public interface Function<T, R> {
    /**
     * Applies this function to the given argument.
     *
     * @param t the function argument
     * @return the function result
     */
    R apply(T t);
}