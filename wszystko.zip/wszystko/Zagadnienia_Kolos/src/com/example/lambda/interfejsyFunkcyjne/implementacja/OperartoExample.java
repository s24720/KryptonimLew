package com.example.lambda.interfejsyFunkcyjne.implementacja;

import com.example.lambda.interfejsyFunkcyjne.UnaryOperator;

import java.util.ArrayList;
import java.util.List;

public class OperartoExample {
    public static void main(String[] args) {

        System.out.println("Interfjesy funkcyjne: ");
        System.out.println("https://programuj.pl/blog/java8-lambdy-praktyczne-przyklady");
        System.out.println("https://developeronthego.pl/java-8-interfejsy-funkcyjne-przeglad/");


        List<String> names = new ArrayList<>();

//    UnaryOperator<String> operator = String::toUpperCase; // alternative to name -> name.toUpperCase()
//names.replaceAll(operator);

    }


}
