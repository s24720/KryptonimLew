package com.example.lambda.interfejsyFunkcyjne.implementacja;

import com.example.lambda.interfejsyFunkcyjne.Function;

import java.util.ArrayList;
import java.util.List;

public class FunctionExample {
    public static void main(String[] args) {

        System.out.println("Interfjesy funkcyjne: ");
        System.out.println("https://programuj.pl/blog/java8-lambdy-praktyczne-przyklady");
        System.out.println("https://developeronthego.pl/java-8-interfejsy-funkcyjne-przeglad/");



        List<String> names = new ArrayList<>();

        names.forEach(nameToCheck -> {
            Function<String, Integer> func = name -> name.length();
            Integer nameLength = func.apply(nameToCheck);
            System.out.println("Length of name " + nameLength);
        });
    }
}
