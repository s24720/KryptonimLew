package com.example.lambda.interfejsyFunkcyjne.implementacja;

import com.example.lambda.interfejsyFunkcyjne.Supplier;

import java.util.ArrayList;
import java.util.List;

public class SupplierExample {
    public static void main(String[] args) {

        int age = 20;
        Supplier<String> ageInfo = () -> "Ania age is " + age;
        List<String> namesWithAges = new ArrayList<>();
        System.out.println(namesWithAges.add(ageInfo.get()));
    }

}
