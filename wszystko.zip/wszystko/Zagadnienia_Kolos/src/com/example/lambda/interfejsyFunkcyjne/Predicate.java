package com.example.lambda.interfejsyFunkcyjne;

//Predykat to kolejny ciekawy interfejs, który umożliwia sprawdzenie, czy dany warunek zachodzi. Funkcja ta waliduje jakiś obiekt, po czym zwraca prawdę albo fałsz.
@FunctionalInterface
public interface Predicate<T> {
    /**
     * Evaluates this predicate on the given argument.
     *
     * @param t the input argument
     * @return {@code true} if the input argument matches the predicate,
     * otherwise {@code false}
     */
    boolean test(T t);
}