package com.example.lambda.interfejsyFunkcyjne;

//Interfejs ten niestety nie występuje w formie ogólnej tak jak poprzednie. Zatem zademonstruję tu najprostszy z nich,
//        zwany UnaryOperator, czyli operator jednoargumentowy. Reprezentuje on operację na pojedynczym parametrze,
//        która daje wynik tego samego typu. Przykładem operatora jednoargumentowego jest znana Ci operacja inkrementacji (np. i++). Masz tu tylko jeden operand (czyli zmienną i).

@FunctionalInterface
public interface UnaryOperator<T> extends Function<T, T> {
    /**
     * Returns a unary operator that always returns its input argument.
     *
     * @param <T> the type of the input and output of the operator
     * @return a unary operator that always returns its input argument
     */
    static <T> UnaryOperator<T> identity() {
        return t -> t;
    }
}