package com.example.lambda.interfejsyFunkcyjne;

//W przeciwieństwie do interfejsu Supplier, ten rodzaj interfejsu skupia się na przetwarzaniu dostarczonej z zewnątrz wartości jednocześnie bez zwracania jakiegokolwiek rezultatu.
@FunctionalInterface
public interface Consumer<T> {
    /**
     * Performs this operation on the given argument.
     *
     * @param t the input argument
     */
    void accept(T t);
}