package com.example.lambda;

import com.example.lambda.abstrakcion.IAmWaitingForAnOrder;
import com.example.lambda.abstrakcion.IPrepareMeal;
import com.example.lambda.abstrakcion.Worker;
import com.example.lambda.observables.*;

public class Main {
    public static void main(String[] args) {


        // utworzenie implementacji interfacu IAmWaitingForAnOrder do którrej przypisujemy klasę Waiter()

        IAmWaitingForAnOrder waiter = new Waiter();
        //IAmWaitingForAnOrder waiter2 = new IAmWaitingForAnOrder();

        /**
         * Utwórz implementacje interface IAmWaitingForAnOrder
         */

        // utworzenie implementacji interface IAmWaitingForAnOrder oraz wyowołanie jej metody

        IAmWaitingForAnOrder anon = new IAmWaitingForAnOrder() {
            @Override
            public boolean ShouldStartWork(Order meal) {

                return true;
            }
        };


        /**
         * Utwórz implementacje klasy Worker
         */

        // utworzenie implementacji klasy Worker/ która za parametr genryczny przyjmuje klasę Chips
        Worker<Chips> chipsWorker = new ChipsWorker();
        /**
         *
         * Utwórz implementacje klasy worker jako klase anonimową
         */

        // Utwórzenie implementacji klasy worker jako klasy anonimowej, która przyjmuje za paraetr genryczny klasę Bererage

        Worker<Bererage> beverageWorker = new Worker<>() {
            @Override //wyowałnie metody perpare z klasy Worker, która za paramtr przyjmuje klasę Bererage
            public Bererage prepare(Order order) {
                return new Bererage();
            }

            @Override //wyowałnie metody ShouldStartWork z klasy Worker
            public boolean ShouldStartWork(Order order) {
                return false;
            }
        };



        /**
         * Utwórz implementacje interfejsów przy pomocy lambd
         */

        // Implementacja interface za pomocą lambdy, któa za parametr generyczny przyjmuje klase Burger
        // jako lambdę przyjmuję order i wuwołuję sout oraz zwraca nową instancję klasy Burger
        IPrepareMeal<Burger> burgerPreparator =
                (order)-> {
                    System.out.println("robie burgera");
                    return new Burger();
                };
        // Przypisane do klasy Burger interface burgerPreparator oraz wwwołanie konstruktowa z Klasy Order
        Burger b = burgerPreparator.prepare(new Order(true, true, true));

        /**
         * Sprawdź co się stanie jak interfejs ma wiecej niz jedną metodę
         */

        /**
         * wykorzystaj lambdy przy tworzeniu klasy GeneralWorker
         */

        // Utwórzenie implementacji klasy worker, która przyjmuje za paraetr genryczny klasę Burger
        // oraz za wartości interface IAmWaitingForAnOrder oraz IPrepareMeal

        Worker<Burger> generalBurgerWorker = new GeneralWorker<>(waiter, burgerPreparator);

        Worker<Bererage> beverageGeneralWorker = new GeneralWorker<>(
                //Order::isBeverageIncluded,
                order ->
                        order.isBeverageIncluded(), // wywoałenie isBeverageIncluded() z klasy Order
                order-> new Bererage()); // wywoałnie klasy Bererage

        Worker<Bererage> beverageGeneralWorker2 = new GeneralWorker<>(
                order ->
                    order.isBeverageIncluded(),  // wywoałenie isBeverageIncluded() z klasy Order
                order->
                        new Bererage()
        );

        // Implementacja klasy Order oraz wywołanie konstruktowa z Klasy Order

        Order beverageOrder = new Order(false,false, true);

        if(beverageGeneralWorker.ShouldStartWork(beverageOrder)) // jeśli rozpocznie pracę
            beverageGeneralWorker.prepare(beverageOrder); // to ma zacząć przygotowywać jedzenie
    }
}
