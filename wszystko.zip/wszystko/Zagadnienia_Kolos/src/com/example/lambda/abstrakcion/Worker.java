package com.example.lambda.abstrakcion;

import com.example.lambda.observables.Order;

// Abstakcyjana klasa Worker z paratemterem generycznym TMeal rozszerzaym przez Meal
// Zmusza to, że że klasa może być parametryzowana tylko przez typy dziedziczące/implementujące Meal

// Worket implementuje Interface IAmWaitingForAnOrder oraz IPrepareMeal z paratmetrem generycznym TMeal

public abstract class Worker<TMeal extends Meal> implements IAmWaitingForAnOrder, IPrepareMeal<TMeal> {
    protected TMeal meal;

    public TMeal getMeal() {
        return meal;
    }

    public void setMeal(TMeal meal) {
        this.meal = meal;
    }


    @Override
    public abstract TMeal prepare(Order order); // abstrakycjna metoda z parametrem generycznym, który przyjmuje za argument klasę Order

    @Override
    public abstract boolean ShouldStartWork(Order order); // abstrakycjna metoda boolean, który przyjmuje za argument klasę Order
}
