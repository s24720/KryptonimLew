package com.example.lambda.abstrakcion;

public abstract class Meal {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
