package com.example.lambda.abstrakcion;

public abstract class LambdaDemo {
    public abstract void work();

}
