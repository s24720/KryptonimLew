package com.example.lambda.abstrakcion;

import com.example.lambda.observables.Order;

public interface IAmWaitingForAnOrder {
    boolean ShouldStartWork(Order order);
}
