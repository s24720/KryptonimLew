package com.example.lambda.abstrakcion;

import com.example.lambda.observables.Order;

public interface IPrepareMeal<TMeal extends  Meal> { // Interface z parametrem generycznm rozszerzanym przez Klasę abstrakycjną Meal
    TMeal prepare(Order order);

    //void giveOrderBack();
}
