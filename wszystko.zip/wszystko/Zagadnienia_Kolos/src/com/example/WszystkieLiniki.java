package com.example;

public class WszystkieLiniki {
    public static void main(String[] args) {

        System.out.println("METODY STRINGl: ");
        System.out.println("https://stormit.pl/string-metody/");

        System.out.println("\nTYTPY GENERYCZNE\n");
        System.out.println("klasa z parametrem typu:");
        System.out.println("https://javappa.com/kurs-java/klasa-z-parametrem-typu");
        System.out.println("Wildcard");
        System.out.println("https://developeronthego.pl/java-typ-wieloznaczny-wildcard/");
        System.out.println("https://www.altkomakademia.pl/baza-wiedzy/qna/discussion/6615/dzikie-karty-w-typach-generycznych/p1");


        System.out.println("LAMBDA\n");
        System.out.println("Opis Lambda: ");
        System.out.println("https://www.samouczekprogramisty.pl/wyrazenia-lambda-w-jezyku-java/");
        System.out.println("Interfjesy funkcyjne: ");
        System.out.println("https://programuj.pl/blog/java8-lambdy-praktyczne-przyklady");
        System.out.println("https://developeronthego.pl/java-8-interfejsy-funkcyjne-przeglad/");

        System.out.println("\nSTRUMIENIE\n");
        System.out.println("Przykłądowe strumienie: ");
        System.out.println("https://czub.info/2016/java-8-strumienie-java-util-stream/");
        System.out.println("Stream co to:   ");
        System.out.println("https://mw.home.amu.edu.pl/zajecia/NIF2017/NIF11.html");
        System.out.println("https://www.samouczekprogramisty.pl/strumienie-w-jezyku-java/");
        System.out.println("https://developeronthego.pl/java-8-stream-api-w-przetwarzaniu-danych/");
        System.out.println("https://programuj.pl/blog/java8-strumienie-cz3-peek-map-collect");
        System.out.println("java collections");
        System.out.println("https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html");
        System.out.println("https://strefainzyniera.pl/artykul/1060/java-collections");
        System.out.println("Mateamtyka strumienie");
        System.out.println("https://www.baeldung.com/java-stream-sum");
        System.out.println("https://www.geeksforgeeks.org/stream-max-method-java-examples/");
        System.out.println("GroupingBy");
        System.out.println("https://javaleader.pl/2019/07/24/java-8-stream-collectors-groupingby/");

        System.out.println("\nREFLEKSJE\n");
        System.out.println("Api Method: ");
        System.out.println("https://docs.oracle.com/javase/8/docs/api/java/lang/reflect/Method.html");
        System.out.println("Api Class: ");
        System.out.println("https://docs.oracle.com/javase/8/docs/api/java/lang/Class.html");
        System.out.println("https://docs.oracle.com/javase/8/docs/api/java/lang/Class.html#getMethods--");
        System.out.println("Api Constructo: ");
        System.out.println("https://docs.oracle.com/javase/8/docs/api/java/lang/reflect/Constructor.html");

        System.out.println("\nAdnotacje\n");
        System.out.println("Adnotacje co to:   ");
        System.out.println("https://www.samouczekprogramisty.pl/adnotacje-w-jezyku-java/");



    }
}
