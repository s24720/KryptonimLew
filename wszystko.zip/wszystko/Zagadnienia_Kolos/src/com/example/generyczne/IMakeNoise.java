package com.example.generyczne;

public interface IMakeNoise {
    void makeNoise();
}
