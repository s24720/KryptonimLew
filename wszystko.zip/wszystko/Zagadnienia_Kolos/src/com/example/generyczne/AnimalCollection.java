package com.example.generyczne;

import java.util.ArrayList;
import java.util.List;

//prarametr generyczny TAnimal ogranicozny/rozszerzony przez klasę Animal orazprarametr generyczny TAnimal2 ogranicozny/rozszerzony przez interface IMakeNoise
public class AnimalCollection<TAnimal extends Animal, TAnimal2 extends IMakeNoise> {

    TAnimal first;
    TAnimal last;
    List<TAnimal> animals = new ArrayList<>();

    //publiczna metoda void dodająca zwierzę
    public void add(TAnimal animal){
        animals.add(animal);
    }
    // publiczban metoda generycna zwracająća index
    public TAnimal getByIndex(int index){
        return animals.get(index);
    }


    <TPrint extends IMakeNoise> void print(TPrint obj){
        obj.makeNoise();

    }
}