package com.example.adnotacje;

import com.example.adnotacje.annotation.AnnotationProcessor;
import com.example.adnotacje.annotation.MyAnnotation;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        var annotationProcessorClass = AnnotationProcessor.class; // Wyowołanie klasy AnnotationProcessor

        Arrays.stream(annotationProcessorClass.getDeclaredFields())
                .filter(field -> field.isAnnotationPresent(MyAnnotation.class)).forEach(field ->
        {
            var annotation = field.getAnnotation(MyAnnotation.class);
            //wypisuje wartości podane w annotacji
            System.out.println(annotation.message());
            System.out.println(annotation.valueMax());
            System.out.println(annotation.valueMin());
        });

        Arrays.stream(annotationProcessorClass.getDeclaredMethods()).
                filter(method -> method.isAnnotationPresent(MyAnnotation.class)).forEach(System.out::println);//wypisuje wszystkie metody zawierające annotacje
        Arrays.stream(annotationProcessorClass.getConstructors()).
                filter(constructor -> constructor.isAnnotationPresent(MyAnnotation.class)).forEach(System.out::println);//wypisuje wszystkie constructory zawierające annotacje


    }
}
