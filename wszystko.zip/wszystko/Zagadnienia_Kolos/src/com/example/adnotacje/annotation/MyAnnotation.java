package com.example.adnotacje.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


//        Brak dyrektywy Target powoduje, że
//        adnotacja może być stosowana do
//        wszystkiego (klas, metod, pól)


@Target({ElementType.TYPE_USE, // deklaracja typu (jak TYPE) oraz typy parametru (jak TYPE_PARAMETER)
        ElementType.FIELD, // deklaracja pola (włączając stałe enum)
        ElementType.METHOD, // deklaracja metody
        ElementType.CONSTRUCTOR,// deklaracja konstruktora

        ElementType.ANNOTATION_TYPE, // deklaracji typu opisów
        ElementType.LOCAL_VARIABLE, // deklaracja zmiennej lokalnej
        ElementType.MODULE, // deklaracja modułu
        ElementType.PACKAGE, // deklaracja pakietu
        ElementType.TYPE, // deklaracja klasy, interfejsu (w tym adnotacji), lub enum
        ElementType.TYPE_PARAMETER // deklaracja typu parametru (generyczne)
})

@Retention(RetentionPolicy.RUNTIME) //Adnotacje są zapisywane w pliku klasy przez kompilator, ale nie muszą być przechowywane przez VM w czasie pracy


/** @Retention(RetentionPolicy.CLASS) */ //adnotacje są zapisywane w pliku klasy przez kompilator i przechowywane przez VM w czasie,
                                        // więc mogą one być odczytywane metodami refleksji.

/** @Retention(RetentionPolicy.SOURCE) */  //adnotacje są odrzucane przez kompilator


public @interface MyAnnotation { // Zdefiniowanie adonatcji

    String message() default "message"; // zdefiniowany parametr z własnością domyłśną
    int valueMin() default 0; // zdefiniowany parametr z własnością domyłśną
    int valueMax() default 10; // zdefiniowany parametr
}
