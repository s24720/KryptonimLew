package com.example.adnotacje.annotation;


import com.example.adnotacje.annotation.MyAnnotation;

@MyAnnotation(message = "1234") // Adnotacja z wiadomością
public class AnnotationProcessor {
    @MyAnnotation(valueMin = 7)
    private final int value;

    @MyAnnotation(valueMax = 69)
    public AnnotationProcessor(int value) {
        this.value = value;
    }

    @MyAnnotation
    private static void printer() {

    }
}
