package com.example.strumienie;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

//Operacje intermediate
//        filter – operacja ta przyjmuje interfejs typu predicate, po którym zostają przefiltrowane elementy, zgodnie z warunkiem zapisanym w lambdzie. Można ją skojarzyć z słowem WHERE w SQL. Z reguły wywołujesz tą akcję jako pierwszą.
//        map – funkcja, która dokonuje przekształcenia poprzedniego obiektu w inny nowy. Działa na każdym elemencie strumienia oddzielnie, w taki sposób, że wszystkie będą zmapowane do nowego typu.
//        sort – ustawienie kolejności elementów. Może przyjąć jako argument compareTo, także w formie lambdy.
//        distinct – zwraca unikalne wartości.
//        limit – ograniczenie wyników do podanego limitu.
//        skip – działa podobnie jak continue w pętli for. W tym przypadku skip opuści, podane w argumencie funkcji, elementy strumienia.

//Operacje terminate
//        forEach – pętla for each ale dla streamów.
//        toArray – konwertuje elementy do typu tablicowego.
//        reduce – dokonuje operacji redukcji.
//        collect – pozwala zwracać kolekcję lub dokonywać grupowania (np. do Stringa).
//        min – zwraca minimalną wartość liczbową opakowaną w Optional. W argumencie wymaga, podobnie jak funkcja sort, aby wskazać sposób w jaki chcesz posortować elementy.
//        max – podobnie jak wyżej, tylko dotyczy szukania wartości maksymalnej.
//        count – policzy, ile elementów występuje w końcowym strumieniu.
//        anyMatch – zwraca wartość typu boolean, gdy jeden element spełnia warunek w argumencie.
//        allMatch – zwraca wartość typu boolean, gdy wszystkie elementy spełniają warunek w argumencie.
//        noneMatch– zwraca wartość typu boolean, gdy żaden z elementów nie spełnia warunku w argumencie.
//        findAny – szuka aż znajdzie jakąkolwiek wartość spełniającą warunek i zwraca ją (działa niedeterministycznie).
//        findFirst – szuka aż napotka pierwszą wartość spełniającą warunek i również ją zwróci.

//Operacja reduce
//        Ciekawym rodzajem funkcji, są operacje typu reduce, które poniekąd łączą cech zarówno operacji terminate jak i intermediate. Operacja reduce pozwala, za pomocą wyrażenia lambda, na złączenie wszystkich elementów strumienia w jeden rezultat.
//
//        Akcja ta posiada trzy charakterystyczne pozycje:
//
//        Identity – wartość początkowa i domyślna, na wypadek, gdyby strumień, był pusty (nieobowiązkowa).
//        Accumulator – wyrażenie lambda, które będzie „przepisem”, w jaki sposób złączyć elementy.
//        Combiner – w przypadku użycia strumieni równoległych (parallel stream), będzie to funkcja, która złączy wyniki poszczególnych części strumienia w całość. Jeśli skorzystasz z pojedynczego strumienia, to można pominąć to pole.

public class Main {
    public static void main(String[] args) {

        System.out.println("-------------------------Liniki do stron------------------------------");
        System.out.println("https://mw.home.amu.edu.pl/zajecia/NIF2017/NIF11.html");
        System.out.println("https://developeronthego.pl/java-8-stream-api-w-przetwarzaniu-danych/");
        System.out.println("https://programuj.pl/blog/java8-strumienie-cz3-peek-map-collect");
        System.out.println("https://www.samouczekprogramisty.pl/strumienie-w-jezyku-java/");
        System.out.println("https://strefainzyniera.pl/artykul/1060/java-collections");
        System.out.println("https://docs.oracle.com/javase/8/docs/api/java/util/stream/Collectors.html");
        System.out.println("https://www.baeldung.com/java-stream-sum");



        ArrayList<Car> cars = new ArrayList<>();
        cars.add(new Car("Dodge", 250, 300000, 4));
        cars.add(new Car("Ford", 260, 200000, 4));
        cars.add(new Car("Ciotroen", 200, 50000, 3));
        cars.add(new Car("Audi", 350, 500000, 5));
        cars.add(new Car("Merc", 300, 10000, 4));
        cars.add(new Car("Porsche", 300, 800000, 5));
        cars.add(new Car("BMW", 240, 30000, 3));


        System.out.println("\n-------------------------Filtrowanie------------------------------");



        List<Car> list = cars.stream()
                .filter(car -> car.price < 300000) // filotrowania
                .collect(Collectors.toList()); // collect do listy

        ArrayList<Car> result = new ArrayList<>(list);
        result.forEach(e -> System.out.println(e));


        System.out.println("\n-------------------------Mapowanie------------------------------");


        List<Integer> carsPrices = cars.stream()
                .filter(car -> car.price < 300000)
                .map(Car::getPrice) // mapowanie
                .collect(Collectors.toList());

        System.out.println(carsPrices);

        System.out.println("\n-------------------------anyMatch------------------------------");


        // anyMatch służy do sprawdzenia, czy którykolwiek z elementów strumienia pasuje do predykatu. Jeśli tak, metoda zwraca true, jeśli nie to false.
       boolean truefalse = cars.stream().anyMatch(i -> i.name == "Audi");
        System.out.println(truefalse); //true


        System.out.println("\n-------------------------noneMatch------------------------------");


        // noneMatch służy do sprawdzenia, czy żaden z elementów nie pasuje do predykatu. Jeśli żaden nie pasuje, metoda zwraca true, jeśli jakiś pasuje zwraca false.
        boolean truefalse2 = cars.stream().noneMatch(i -> i.name == "Kol");
        System.out.println(truefalse2); //true


        System.out.println("\n-------------------------allMatch------------------------------");

        //allMatch służy do sprawdzenie, czy wszystkie elementy strumienia pasują do predykatu. Jeśli pasują to metoda zwraca true, jeśli nie to false.
        boolean truefalse3 = cars.stream().allMatch(i -> i.rating > 2);
        System.out.println(truefalse3); //true


        System.out.println("\n-------------------------Metoda limit------------------------------");

        // limit ograniczenie wyników do podanego limitu
        List<Car> limit = cars.stream()
                .filter(car -> car.price < 500000)
                .limit(1) // limit wyznaczony na jeden
                .collect(Collectors.toList());

        List<Car> limit2 = cars.stream()
                .filter(car -> car.price < 500000)
                .limit(2) // limit wyznaczony na dwa
                .collect(Collectors.toList());

        System.out.println("Limit ustawiony na 1");
        System.out.println(limit);
        System.out.println("\nLimit ustawiony na 2");
        System.out.println(limit2);


        System.out.println("\n-------------------------Metoda distinct------------------------------");


        // distinct zwraca unikalne wartości
        List<Integer> distnic = cars.stream()
                .map(Car::getRating)
                .distinct() // zwraca unikalne wartości
                .collect(Collectors.toList());

        System.out.println(distnic);


        System.out.println("\n-------------------------Metoda skip------------------------------");


        // skip działa podobnie jak continue w pętli for. W tym przypadku skip opuści, podane w argumencie funkcji, elementy strumienia.
        List<Car> skip = cars.stream()
                .filter(car -> car.price < 500000)
                .skip(1) // Opuszcza pierwszy elemnt strumienia
                .collect(Collectors.toList());

        System.out.println(skip); // zamiast Dodge jest Ford pierwszy


        System.out.println("\n-------------------------Metoda sorter------------------------------");


        // sort ustawienie kolejności elementów. Może przyjąć jako argument compareTo, także w formie lambdy.
        List<String> sort = cars.stream() // żeby mapować trzeba ustawić W liście czy to String, Integer itp.
                .map(Car::getName)
                .sorted(Comparator.reverseOrder()) //reverseOrder - sortowanie malejące
                .collect(Collectors.toList());

        System.out.println("Posortowane malejąco");
        System.out.println(sort);

        List<String> sort2 = cars.stream()
                .map(Car::getName)
                .sorted() //sortowannie rosnące
                .collect(Collectors.toList());

        System.out.println("\nPosortowane rosnąco");
        System.out.println(sort2);

        List<String> sort3 = cars.stream()
                .sorted(Comparator.comparing(Car::getRating)  //Sortowanie według oceny i ceny
                        .thenComparing(Car::getPrice))
                .map(Car::getName)
                .collect(Collectors.toList());

        System.out.println("\nSortowanie według oceny i ceny");
        System.out.println(sort3);

        List<String> sort4 = cars.stream()
                .sorted(Comparator.comparing(Car::getRating) //Sortowanie według oceny i ceny malejąco
                        .reversed()
                        .thenComparing(Car::getPrice))
                .map(Car::getName)
                .collect(Collectors.toList());

        System.out.println("\nSortowanie według oceny i ceny malejąco");
        System.out.println(sort4);


        System.out.println("\n-------------------------Collectors------------------------------");

        System.out.println("\n-------------------------Collector map------------------------------");

        // Mapa pozwala nam stworzyć łańcuch znaków i popierać z niego dany obiekt
        Map<String, Car> map = cars.stream()
                .collect(Collectors.toMap(Car::getName, car -> car)); //To map dokonuje mapowania wedle wzoru
                  // .collect(Collectors.toMap(car -> car.name, car -> car));

        //Metoda toMap korzysta z dwóch argumentów: Function.identity, która po prostu kopiuje te same wartości, które są w liście oraz lambda, która zwraca nowozdefiniowany String.

        System.out.println("Wyświetelenie całej listy");
        System.out.println(map);


        System.out.println("\nWyswietlenie Wiersza z nazwą ustawioną na Audi");
        Car car1 = map.get("Audi");
        System.out.println(car1);


        System.out.println("\n-------------------------Collector groupingBy------------------------------");
        System.out.println("https://javaleader.pl/2019/07/24/java-8-stream-collectors-groupingby/");

        //Umożliwia on zebranie elementów strumienia do mapy, grupując je według podanej cechy

        Map<String, List<Car>> groupingBy = cars.stream()
                .collect(Collectors.groupingBy(c -> c.getName())); // zgrupowanie na podstawie nazw

        System.out.println("--- mapa wynikowa ---");
        System.out.println(groupingBy);

        List<Car> group = groupingBy.get("Wybranie Audi"); // wybranie tylko Audi
        System.out.println("Audi");

        System.out.println(group);


        System.out.println("\n-------------------------Collector Obliczenia------------------------------");


        // Stream.reduce() to operacja terminalowa, która dokonuje redukcji elementów strumienia .
        System.out.println("\n-------------------------Stream.reduce()------------------------------");
        System.out.println("https://www.baeldung.com/java-stream-sum");

        System.out.println("redukcja ocen sposób 1");
        Integer reduce = cars.stream()
                .map(Car::getRating)
                .reduce(0, Integer::sum);

        System.out.println(reduce);

        System.out.println("redukcja ocen sposób 2");
        Integer reduce2 = cars.stream()
                .map(Car::getRating)
                .reduce(0, (a, b) -> a + b);

        System.out.println(reduce2);


        //  obliczanie sumy listy liczb całkowitych jest użycie  terminalowej operacji collect()
        //  Podobnie klasa Collectors udostępnia metody summingLong() i summingDouble() do obliczania odpowiednio sum długich i podwójnych.
        System.out.println("\n-------------------------Stream.collect()------------------------------");

        System.out.println("obliczanie ocen INTEGER collect");
        Integer collect = cars.stream()
                .collect(Collectors.summingInt(Car::getRating));

        System.out.println(collect);


        System.out.println("obliczanie ocen Double collect");
        Double collect2 = cars.stream()
                .collect(Collectors.summingDouble(Car::getRating));

        System.out.println(collect2);



        System.out.println("https://www.geeksforgeeks.org/stream-max-method-java-examples/");
        System.out.println("https://developeronthego.pl/java-8-stream-api-w-przetwarzaniu-danych/");

        System.out.println("Metoda max - wyświelta największą wartość");
        Integer max = cars.stream()
                .map(Car::getPrice)
                .max(Integer::compare)
                        .get();

        System.out.println(max);


        System.out.println("\n-------------------------MAX/MIN------------------------------");

        System.out.println("Metoda min - wyświelta najmniejszą wartość");
        Integer min = cars.stream()
                .map(Car::getPrice)
                .min(Integer::compare)
                .get();

        System.out.println(min);


        System.out.println("Metoda min - wyświelta najmniejszą wartość");
        Integer mine = cars.stream()
                .map(Car::getPrice)
                .min(Integer::compare)
                .get();

        System.out.println(mine);


        System.out.println("\n-------------------------findAny()/findFirst()------------------------------");

        System.out.println("findAny rzykład 1");
        // szuka aż znajdzie jakąkolwiek wartość spełniającą warunek i zwraca ją
        Optional<Car> findAny = cars.stream().findAny();

        if (findAny.isPresent()) {
            System.out.println(findAny.get());
        }
        else {
            System.out.println("no value");
        }


        System.out.println("findAny rzykład 2");
        IntStream stream = IntStream.of(4, 5, 8, 10, 12, 16)
                .parallel();

        stream = stream.filter(i -> i % 4 == 0);

        OptionalInt answer = stream.findAny();
        if (answer.isPresent())
        {
            System.out.println(answer.getAsInt());
        }


        System.out.println("findFirst rzykład 1");
        // szuka aż znajdzie pierwszą wartość spełniającą warunek i zwraca ją
        Optional<Car> findFirs = cars.stream().findFirst();

        System.out.println("findFirs rzykład 1");
        if (findFirs.isPresent()) {
            System.out.println(findFirs.get());
        }
        else {
            System.out.println("no value");
        }


        //Stream API udostępnia nam pośrednią operację mapToInt() , która konwertuje nasz strumień na obiekt IntStream .
        //Ta metoda przyjmuje jako parametr mapper, którego używa do wykonania konwersji, następnie możemy wywołać metodę sum() w celu obliczenia sumy elementów strumienia.
        //W ten sam sposób możemy użyć metod mapToLong() i mapToDouble() do obliczenia odpowiednio sumy długich i podwójnych.
        System.out.println("\n-------------------------IntStream.sum()------------------------------");

        System.out.println("obliczanie ocen INTEGER .sum()");

        Integer sum = cars.stream()
                .mapToInt(Car::getRating)
                .sum();
        System.out.println(sum);


        System.out.println("obliczanie ocen DOUBLE .sum()");
        Double sum2 = cars.stream().
                mapToDouble(Car::getRating).sum();

        System.out.println(sum2);


        System.out.println("\n-------------------------Używanie strumienia#sum z obiektami------------------------------");
        System.out.println("https://www.baeldung.com/java-stream-sum");


        System.out.println("\n-------------------------Używanie strumienia#sum z napisem------------------------------");

        System.out.println("Item1 10 Item2 25 Item3 30 Item4 45");
        System.out.println("Zliczenie liczb z ciągu");
        String string = "Item1 10 Item2 25 Item3 30 Item4 45";
        Integer stringSum = Arrays.stream(string.split(" "))
                .filter((s) -> s.matches("\\d+"))
                .mapToInt(Integer::valueOf)
                .sum();

        System.out.println(stringSum);


        System.out.println("\n-------------------------Kilka innych metod COLLECTORS------------------------------");

        // zlicza wskazaną liczbę elementów
        System.out.println("\n-------------------------Zliczanie liczby elementów za pomocą counting()------------------------------");

        System.out.println("counting zliczenie liczby elementów ocen metoda 1");
        long counting = cars.stream()
                .map(Car::getRating)
                .collect(Collectors.counting());

        System.out.println(counting);

        System.out.println("counting zliczenie liczby elementów ocen metoda 2");
        long counting2 = cars.stream()
                .map(Car::getRating).count();

        System.out.println(counting2);

        long counting3 = cars.stream()
                .map(Car::getName).count();

        System.out.println("counting zliczenie liczby elementów nazaw metoda 1");
        System.out.println(counting3);

        //Metoda join () klasy Collectors w Javie służy do łączenia różnych elementów tablicy znaków lub łańcuchów w pojedynczy obiekt łańcuchowy. Ta metoda wykorzystuje do tego strumień.
        System.out.println("\n-------------------------Łączenia różnych elementów za pomocą joining()------------------------------");


        System.out.println("Przykłąd 1");
        char[] ch = { 'G', 'e', 'e', 'k', 's', 'f', 'o',
                'r', 'G', 'e', 'e', 'k', 's' };

        String chString
                = Stream.of(ch)
                .map(arr -> new String(arr))
                .collect(Collectors.joining());

        System.out.println(chString);

        System.out.println("\nPrzykłąd 2");
        String joing = cars.stream()
                .map(Car::getName)
                .collect(Collectors.joining(","));
        System.out.println(joing);




    }
}
