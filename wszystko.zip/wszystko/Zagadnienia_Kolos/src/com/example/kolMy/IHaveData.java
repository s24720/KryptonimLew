package com.example.kolMy;

import java.util.List;

public interface IHaveData<TItem> {
    List<TItem> getData();

    public void showData();
}
