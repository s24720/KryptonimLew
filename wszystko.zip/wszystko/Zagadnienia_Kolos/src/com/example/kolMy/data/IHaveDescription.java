package com.example.kolMy.data;

public interface IHaveDescription {
    String getDescription();
}
